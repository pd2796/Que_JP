interface A
{
 default void aaa() // error
   {
    System.out.println("PD");
   }}
interface B
{
   default void bbb() // error
   {
    System.out.println("PD");
   }
}

class InterfaceEx implements A,B
{
  
   public static void main(String args[])
   {
        InterfaceEx c = new InterfaceEx();
        c.aaa();
   }
}