import java.util.*;
import java.util.stream.*;

public class T {
    public static void main(String[] args) {
        List<String> s=  Arrays.asList("abc","","bcd","","defg","jk");
        long c = s.stream().filter(x->x.isEmpty()).count();
        System.out.println(c);
        long c1 = s.stream().filter(x->x.length() >3).count();
        System.out.println(c1);
        List<String> st=  Arrays.asList("abc","bcd","defg","jk");

        String cs = st.stream().map(x->x.toUpperCase()).collect(Collectors.joining(", "));
        System.out.println(cs);
        
        
    }
}
