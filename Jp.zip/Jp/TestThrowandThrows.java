class TestThrowandThrows {
    static void method() throws ArithmeticException{
        System.out.println("throwing");
        throw new ArithmeticException("throwing ArithmeticException");
    }

    public static void main(String a[])
    {
        try{
            method();
        }
        catch(ArithmeticException e)
        {
            System.out.println("caught main method");
        }
    }
}