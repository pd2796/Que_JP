import java.util.*;
class Collection1{
                            static int l=10;

   static final int integerConstant=20;
    public static void main(String args[]){  
                                    final int ui = 2243;

        ArrayList<String> list = new ArrayList<String>();
        list.add("ss");
        Iterator itr=list.iterator();  
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
        List<String> list1= new LinkedList<String>();
        list1.add("lp");        Iterator itr1=list1.iterator();  
        Collection1 c = new Collection1();
        System.out.print(ui);
        while(itr1.hasNext())
        {
            System.out.println(itr1.next());
        }  

        HashSet<String> h = new HashSet<>();
        h.add("a");
        h.add("a");
        h.add("aa"); 
         Iterator itr12=h.iterator();  

        while(itr12.hasNext())
        {
            System.out.println(itr12.next());
        }

        Map<Integer,String> map = new HashMap<Integer,String>();
        map.put(100,"Amit");
        map.put(101,"Vijay");
        map.put(101,"Vijayll");
        map.put(null,"Vissjay");
        map.put(null,"Vissjdssay");

        for(Map.Entry m:map.entrySet()){
            System.out.println(m.getKey()+""+m.getValue());
        }
                final int s = 223;
                l=20;
                System.out.println(l);
                System.out.println(integerConstant);

        }
}