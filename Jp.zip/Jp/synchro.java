import java.util.HashMap;
import java.util.Map;

class synchro{
    public static void main(String a[])
    {
        HashMap<Integer,Integer> z = new HashMap<>();
        HashMap<Integer,Integer> z1 = new HashMap<>();
            
        z1.put(1, 1);

        z.put(1, 2);
        
        System.out.println(z.hashCode());
          
        System.out.println(z1.hashCode());

        System.out.println(z);

System.out.println(z1);
        
        
    }
}