class complex
{
    private double re,im;
    public complex(double re,double im)
    {
        this.re = re;
        this.im = im;
    }
    complex(complex c)
    {
        System.out.println("copy constructor called");
        re= c.re;
        im = c.im;
    }
    @Override public String toString(){
        return "(" + re + " + " + im + ")";
    }
}


public class copycons {

    public static void main(String a[])
    {
        complex c1 = new complex(50,20);
        complex c2 = new complex(c1);
        complex c3 = c2;
        System.out.println(c2);
    }
    
}
