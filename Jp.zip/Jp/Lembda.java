interface Sayble {
    public String say(String name);
}

public class Lembda{
public static void main(String s[]){

    // Annonyam class
    Sayble st = new Sayble(){
        public String say(String name)
        {
             String t = "Hello,"+name;
                System.out.println(name);
              return t;
        }
    };
    st.say("Yash");

    Sayble s1 = (name) ->{
            return "Hello,"+name;
    };
    Runnable r = () ->{
        System.out.println("Runnable with Lambda Expression");

    };
    new Thread(r).start();

    System.out.println(s1.say("Parth"));
}
}