import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.io.*;

class Movie implements Comparable<Movie>
{
    private double rating;
    private String name;
    private int year;

    public int compareTo(Movie m)
    {
        return this.year - m.year;

    }
    public Movie(String nm, double rt,int yr)
    {
        this.name = nm;
        this.rating = rt;
        this.year = yr;

    }
    public double getRating(){
        return rating;
    }
    public String getName(){
        return name;
    }
    public int getYear(){
        return year;
    }
}

class RatingCompare implements Comparator<Movie>
{
    public int compare(Movie m1, Movie m2)
    {
        if(m1.getRating() < m2.getRating()) 
        {return 1;}
        if(m1.getRating() > m2.getRating()) 
        {return -1;}
        else{
            return 0;
        }
        

    }
} 

class NameCompare implements Comparator<Movie>
{
    public int compare(Movie m1,Movie m2)
    {
        return m1.getName().compareTo(m2.getName());
    }
}
class cm  {
    public static void main(String a[])
    {
        ArrayList<Movie> list = new ArrayList<Movie>();
        list.add(new Movie("Zinga",10.1,2021));
        list.add(new Movie("Shingham",8.3,2015));
        list.add(new Movie("Dabang",9.0,2018));
        list.add(new Movie("Three Idiot",10.0,2011));

        System.out.println(list);
        Collections.sort(list);

        System.out.println(list);
        System.out.println("Movies after sorting");

        System.out.println("\nSorted by year");
        for(Movie movie:list)
        {
            System.out.println(movie.getName()+" "+movie.getRating()+" "+movie.getYear());
        }


        System.out.println("\nSorted by name");

        NameCompare nameCompare = new NameCompare();
        Collections.sort(list, nameCompare);
        for(Movie movie:list)
        {
            System.out.println(movie.getName()+" "+movie.getRating()+" "+movie.getYear());
        }

        System.out.println("\nSorted by Rating");

        RatingCompare ratingCompare = new RatingCompare();
        Collections.sort(list, ratingCompare);
        for(Movie movie:list)
        {
            System.out.println(movie.getName()+" "+movie.getRating()+" "+movie.getYear());
        }

    }
}
