class StringTest{
    public static void main(String as[])
    {
        String s = new String("hi");
        String s1 = "hi";

        System.out.println(s.equals(s1));
                System.out.println(s==s1);

    }
}