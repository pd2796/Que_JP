import java.sql.DatabaseMetaData;
import java.text.ChoiceFormat;
import java.text.Format;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class hlp {
    static int n2 = getValue();
    static int n1 = 10;
    static int getValue()
    {
        return n1;
    }
    static int doSum(){
        return n1+n2;
    }
    static int doMin(){
        return n1-n2;
    }
    public static void main(String[] args)
    {
        System.out.println(doSum());
        System.out.println(doMin());
    }
}



