
// input : {Aproan, Application, Apple}
// output :: Ap
 
// input :: {Apple, Application}
// output :: Appl

// input :: "ABC PQR XYZ"
// output :: "CBA RQP ZYX"
import java.util.*;
import java.util.stream.*;

public class EachWordReverce {

    public static void main(String as[])
    {
        String input = "alex brian charles";

        String reversed = Arrays.stream(input.split(" "))
            .map(word -> new StringBuilder(word).reverse())
            .collect(Collectors.joining(" "));
        
        System.out.println(reversed);

      
    }
    
}
