 class cls{
    public static void main(String op[])
    {
        System.out.print("ssss");
    }
}