class Apple{

   }

public class ThreadEx extends Apple implements Runnable {
   
    public void run()
    {
        System.out.println("Heloo runnable interface");
    }
    
    public static void main(String lp[])
    {
        ThreadEx t1 = new ThreadEx();
        Thread t = new Thread(t1);
        t.start();
        

    }



}
