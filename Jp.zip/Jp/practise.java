interface zp
{
  public default void mn()
    {
        System.out.println("null");
    }
}
interface ip
{
  public default void en()
    {
        System.out.println("null");
    }
}
public class practise extends Exception implements ip,zp{
    int add(){
        return 20;
    }
    static int i = 10;
    
    public static void main(String []a)
    {
       

        ip.en();
                System.out.println("gull");

    }
    
}