interface ref{
    //void re();
        Message getMessage(String msg);  

}
class Message{  
    Message(String msg){  
        System.out.print(msg);  
    }  
} 
class MethodRef{
    public static void saySomething(){
                System.out.println("Hello, this is static method.");  

    }
public static void main(String ap[])
{
    // ref r = MethodRef::saySomething;
    // r.re();
    ref r1 = Message::new;
    r1.getMessage("PD");
}
}