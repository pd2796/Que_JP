import java.util.Optional;

public class optional {
    
    public static void main(String a[])
    {
        String[] words = new String[10];

        Optional<String> checkNull = Optional.ofNullable(words[5]);

        if(checkNull.isPresent())
        {
            String word = words[5].toLowerCase();
            System.out.print(word);
 
        }else
        {
            System.out.print("is null");

        }
    }
}
