
public class ThreadEx1 extends Thread {

 public void run()
 {
     System.out.println("Heloo Thread Class");
 }
 
 public static void main(String lp[])
 {
     ThreadEx1 t1 = new ThreadEx1();
     Thread t = new Thread(t1);
     t.start();
     

 }



}
