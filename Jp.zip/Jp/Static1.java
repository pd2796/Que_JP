class Static1 {
   
    // Static block
    static
    {
        // Print statement
        System.out.print(
            "Static block can be printed without main method");
    }
}