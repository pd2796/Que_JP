import java.util.HashMap;

public class StringOccurance {
    public static void main(String[] args)
	{

		// Declaring the String
		String str = "Alice is is girl and Bob is boy";
		// Declaring a HashMap of <String, Integer>
		HashMap<String, Integer> hashMap = new HashMap<>();
        String[] words = str.split(" ");

        for(String word:words)
        {
            Integer integer = hashMap.get(word);
            if(integer == null)
            {
                hashMap.put(word,1);
            }
            else
            {
                hashMap.put(word,integer+1);

            }

        }
        System.out.println(hashMap);

    }
}
