import java.util.*;
import java.util.stream.*;

public class preFix {
    public static void main(String[] args) {
       String str = "Malyalam";
       String[] prefixArr = { "Ga", "Ma", "yalam" };
       if (Stream.of(prefixArr)
          .anyMatch(str::startsWith))
          System.out.println("TRUE");
       else
          System.out.println("FALSE");
    }
 } 
