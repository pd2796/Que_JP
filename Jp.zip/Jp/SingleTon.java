class Single{

    private static Single single = null;
    public String s;
  
    // Constructor
    // Here we will be creating private constructor
    // restricted to this class itself
    private Single()
    {
        s = "Hello I am a string part of Singleton class";
    }
    public static Single getInstance()
    {
        if(single==null)
            {
                single = new Single();
            }
            return single;
    }

}
class SingleTon {

    public static void main(String a[])
    {
        Single s = Single.getInstance();
        Single s1 = Single.getInstance();
        System.out.print(s.hashCode() + " " + s1.hashCode()); 
    }
}