import java.util.*;
import java.util.stream.*;

class StreamDemo {
        public static void main(String args[]) {
                List<Integer> number = Arrays.asList(2, 3, 4, 5, 1, 1);
                List<Integer> list = number.stream().map(x -> x * 5).collect(Collectors.toList());
                System.out.println(list);

                List<String> names = Arrays.asList("Reflection", "Collection", "Stream");
                List<String> list1 = names.stream().filter(s -> s.startsWith("S")).collect(Collectors.toList());
                System.out.println(list1);

                List<Integer> show = number.stream().sorted().collect(Collectors.toList());
                System.out.println(show);
                number.stream().sorted().forEach(y -> System.out.println(y));

                Set<Integer> st = number.stream().map(x -> x * 5).collect(Collectors.toSet());
                System.out.println(st);
                int stq = number.stream().filter(x -> x % 2 == 0).reduce(0, (ans, i) -> ans + i);
                System.out.println("reduce "+stq);
                List<Integer> distinctInts = number.stream().distinct().collect(Collectors.toList());
                System.out.println(distinctInts);

                Map<String, String> map = new HashMap<>();
                map.put("C", "c");
                map.put("B", "b");
                map.put("Z", "z");
                List<Map.Entry<String, String>> sortedByKey = map.entrySet().stream().sorted(Map.Entry.comparingByKey())
                                .collect(Collectors.toList());
                sortedByKey.forEach(System.out::println);
                map.forEach((k, v) -> System.out.println(k + " " + v));
        }
}