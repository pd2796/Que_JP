
public class StringBuilderTest {
    public static void main(String[] args) {

   
    String str = "Automation";
    StringBuilder sp = new StringBuilder();
    sp.append(str);
    sp.reverse();
    System.out.println(sp);

    String str1 = "Saket Saurav";
    char chars[] = str1.toCharArray();
    for(int i = chars.length-1;i>=0;i--)
    {
        System.out.println(chars[i]);

    }
}
}