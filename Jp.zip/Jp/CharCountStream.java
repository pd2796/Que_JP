import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CharCountStream {
    public static void main(String a[])
    {
        String input = "Spring and Hibernate and Web Services";

        Map<Character,Long> charcterCountMap = input.chars()
        .mapToObj(c->(char) c).filter(ch -> !Character
        .isWhitespace(ch)).collect(Collectors.groupingBy(ch->ch,Collectors.counting()));

        System.out.println("1. Characters and its Count in Random-order :- \n");
        charcterCountMap
        .entrySet()
        .forEach(System.out::println);
    }
}
